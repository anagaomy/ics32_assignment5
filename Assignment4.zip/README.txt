
Class Last.fm - user.getLovedTracks

    user (Required) : The user name to fetch the loved tracks for.
    limit (Optional) : The number of results to fetch per page. Defaults to 50.
    page (Optional) : The page number to fetch. Defaults to first page.
    api_key (Required) : A Last.fm API key.
# a4.py

# Ana Gao
# gaomy@uci.edu
# 26384258

